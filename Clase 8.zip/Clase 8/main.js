function conteoRegresivo(conteo) {

    for (var conteo ; conteo >= 0; conteo--){
        console.log (conteo);    
    }
    console.log("¡Despeguemos!");
}

var numero = prompt("Ingrese un numero para la cuenta regresiva")
conteoRegresivo(numero);